package com.my.vo;

public class Board {

	private int no;
	private String title;
	private String nickname;
	private String content;
	private String regdate;
	private int cnt;
	private String userid;

	public Board(String title, String nickname, String content, String userid) {
		super();
		this.title = title;
		this.nickname = nickname;
		this.content = content;
		this.userid = userid;
	}

	public Board(int no, String title, String nickname, String content,
			String regdate, int cnt, String userid) {
		super();
		this.no = no;
		this.title = title;
		this.nickname = nickname;
		this.content = content;
		this.regdate = regdate;
		this.cnt = cnt;
		this.userid = userid;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRegdate() {
		return regdate;
	}

	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}

	public int getCnt() {
		return cnt;
	}

	public void setCnt(int cnt) {
		this.cnt = cnt;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	@Override
	public String toString() {
		return "Board [no=" + no + ", title=" + title + ", nickname="
				+ nickname + ", content=" + content + ", regdate=" + regdate
				+ ", cnt=" + cnt + ", userid=" + userid + "]";
	}

}
