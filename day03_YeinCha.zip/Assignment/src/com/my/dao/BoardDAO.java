package com.my.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.my.vo.Board;
import com.my.vo.User;

public class BoardDAO {

	public int addBoard(Board board) {
		Connection con = null;
		PreparedStatement ps = null;
		int result = 0;
		try {
			con = DBUtil.getConnection();
			String sql = "insert into board(seq, title, nickname, content, regdate, userid)  values((select nvl(max(seq), 0)+1 from board), ?, ?, ?, sysdate, ?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, board.getTitle());
			ps.setString(2, board.getNickname());
			ps.setString(3, board.getContent());
			ps.setString(4, board.getUserid());
			result = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(ps);
			DBUtil.close(con);
		}
		return result;
	}

	public List<Board> searchAll() {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Board board = null;
		List<Board> list = new ArrayList<Board>();
		try {
			con = DBUtil.getConnection();
			String sql = "select * from board order by seq";
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				board = new Board(rs.getInt(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getInt(6), rs.getString(7));
				list.add(board);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(ps);
			DBUtil.close(con);
		}
		return list;
	}
	
	public Board searchByNo(int no) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Board board = null;
		try {
			con = DBUtil.getConnection();
			String sql = "select * from board where seq=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, no);
			rs = ps.executeQuery();
			if(rs.next()) {
				board = new Board(rs.getInt(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getInt(6), rs.getString(7));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(ps);
			DBUtil.close(con);
		}
		return board;
	}
}
