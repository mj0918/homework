package com.my.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.my.dao.UserDAO;
import com.my.vo.User;

/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String action = request.getParameter("action");
		if (action.equals("input")) {
			userInput(request, response);
		} else if (action.equals("searchById")) {
			userSearchById(request, response);
		} else if (action.equals("searchAll")) {
			userSearchAll(request, response);
		} 
	}
	
	public void userSearchAll(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		UserDAO dao = new UserDAO();
		List<User> list = dao.searchAll();
		request.setAttribute("list", list);
		request.getRequestDispatcher("userList.jsp").forward(request, response);
	}
	
	public void userSearchById(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		String id = request.getParameter("id");
		UserDAO dao = new UserDAO();
		List<User> list = dao.searchById(id);
		request.setAttribute("list", list);
		request.getRequestDispatcher("userList.jsp").forward(request, response);
	}

	
	public void userInput(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String role = request.getParameter("role");
		UserDAO dao = new UserDAO();
		User user = new User(id, password, name, role);
		int result = dao.addUser(user);
		request.setAttribute("result", result);
		request.setAttribute("user", user);
		request.getRequestDispatcher("userInput.jsp").forward(request, response);
	}
}
