package com.my.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.my.dao.BoardDAO;
import com.my.dao.UserDAO;
import com.my.vo.Board;
import com.my.vo.User;

/**
 * Servlet implementation class BoardServlet
 */
public class BoardServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BoardServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String action = request.getParameter("action");
		if (action.equals("input")) {
			boardInput(request, response);
		} else if (action.equals("searchByNo")) {
			boardSearchByNo(request, response);
		} else if (action.equals("searchAll")) {
			boardSearchAll(request, response);
		} 
	}
	
	public void boardSearchByNo(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		int no = Integer.parseInt(request.getParameter("no"));
		System.out.println("번호:"+no);
		BoardDAO dao = new BoardDAO();
		Board board = dao.searchByNo(no);
		System.out.println(board.toString());
		request.setAttribute("board", board);
		request.getRequestDispatcher("boardDetail.jsp").forward(request, response);
	}
	
	public void boardSearchAll(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		BoardDAO dao = new BoardDAO();
		List<Board> list = dao.searchAll();
		request.setAttribute("list", list);
		request.getRequestDispatcher("boardList.jsp").forward(request, response);
	}
	
	public void boardInput(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		String title = request.getParameter("title");
		String nickname = request.getParameter("nickname");
		String id = request.getParameter("id");
		String content = request.getParameter("content");
		BoardDAO dao = new BoardDAO();
		Board board = new Board(title, nickname, content, id);
		dao.addBoard(board);
		boardSearchAll(request, response);
	}

}
